export default {
  input: 'src/sva.js',
  output: {
    file: 'build/sva.js',
    format: 'esm',
  }
}
